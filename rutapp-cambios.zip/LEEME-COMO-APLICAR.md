# Cómo aplicar estos cambios a rutapp

Este ZIP contiene **10 ficheros ya modificados**, con la misma ruta que tienen
en el repo. No es un parche: son los ficheros completos, listos para sustituir
a los actuales.

Base: commit `0f5698e` de `main`.

---

## IMPORTANTE: GitHub no descomprime ZIPs

Subir este ZIP al repo no aplica nada — quedaría como un fichero más.
Hay que descomprimirlo primero y subir los ficheros ya extraídos.

---

## Opción A — con git en un ordenador (recomendado)

```bash
cd ruta/a/tu/rutapp
git pull
unzip -o /ruta/al/rutapp-cambios.zip -d .
rm LEEME-COMO-APLICAR.md
git add -A
git commit -m "fix(sync): cola de sincronizacion, firma debug estable y formulario en cards"
git push origin main
```

`unzip -o` sobrescribe respetando las carpetas. Revisa antes con `git diff`.

---

## Opción B — desde la web de GitHub, sin git

1. Descomprime el ZIP en tu ordenador o móvil.
2. En GitHub: repo → botón `Add file` → `Upload files`.
3. **Arrastra las carpetas `app`, `gradle` y `.github` enteras**, no los
   ficheros sueltos: al arrastrar carpetas, GitHub conserva las rutas y
   sustituye los ficheros existentes.
4. Escribe el mensaje de commit y confirma.

Si tu navegador no deja arrastrar carpetas, hazlo fichero a fichero:
abre cada uno en GitHub, lápiz de editar, borra el contenido, pega el nuevo.
Son 10 ficheros; las rutas están en la lista de abajo.

---

## ANTES de que CI compile: crear el secret

El workflow nuevo **falla a propósito** si falta el keystore, para no volver a
generar APKs con clave aleatoria que borran los datos del dispositivo.

GitHub → Settings → Secrets and variables → Actions → New repository secret
- Nombre: `DEBUG_KEYSTORE_B64`
- Valor: el contenido de `DEBUG_KEYSTORE_B64.txt` (todo, en una sola línea)

Guarda también `debug.keystore` en un sitio seguro y con copia. Si lo pierdes,
la siguiente actualización volverá a exigir desinstalar y se perderán los datos
locales que no hayan subido.

---

## Ficheros incluidos

| Fichero | Qué cambia |
|---|---|
| `app/src/main/kotlin/com/pabl3st/rutapp/data/local/dao/SyncQueueDao.kt` | `purgeOlderThan` pasa a `Long` (vaciaba la cola entera); umbral de reintentos 5 → 20; nuevo `resetExhausted()` |
| `app/src/main/kotlin/com/pabl3st/rutapp/data/repository/SyncRepository.kt` | cutoff de purga en millis; batch alineado a 20 intentos |
| `app/src/main/kotlin/com/pabl3st/rutapp/feature/rutas/RutasViewModel.kt` | el botón de sync reactiva ops agotados antes de subir |
| `app/src/main/kotlin/com/pabl3st/rutapp/feature/rutas/RouteDetailScreen.kt` | botón de formulario en las cards; `onStopClick` estaba sin cablear |
| `app/src/main/kotlin/com/pabl3st/rutapp/feature/rutas/RouteMapScreen.kt` | formulario arriba, navegar debajo, en las cards del mapa |
| `app/src/main/kotlin/com/pabl3st/rutapp/data/network/RutasApiService.kt` | `@JsonClass` en los 5 DTOs del panel God |
| `app/src/main/kotlin/com/pabl3st/rutapp/di/NetworkModule.kt` | fuera el fallback reflexivo de Moshi |
| `gradle/libs.versions.toml` | `moshi-kotlin` → `moshi`; nueva entrada solo para tests |
| `app/build.gradle.kts` | `signingConfigs` con keystore debug estable |
| `.github/workflows/build-debug.yml` | restaura el keystore desde el secret |

---

## Recordatorios pendientes

- `api.php` parcheado: **ya desplegado** (health devuelve `version 1.1.0`).
- `UPDATE users SET manager_id = 1 WHERE id = 24;` — el agente `Shimba2021`
  está huérfano y sin eso no hereda visibilidad por jerarquía.
- `app/google-services.json` sigue trackeado en un repo público.
- Los dos tokens de GitHub pegados en el chat siguen sin revocar.
