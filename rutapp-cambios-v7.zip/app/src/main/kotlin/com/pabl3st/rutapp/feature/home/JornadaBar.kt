@file:OptIn(ExperimentalMaterial3Api::class)
package com.pabl3st.rutapp.feature.home

import com.pabl3st.rutapp.core.ui.theme.RouteStatus

import com.pabl3st.rutapp.core.ui.theme.StopStatus

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun JornadaBar(
    routeUid: String,
    modifier: Modifier = Modifier,
    /** Fecha de la jornada. null = hoy. Se pasa la fecha de la ruta para que
     *  una ruta rellenada a posteriori cierre su jornada en SU dia. */
    routeDate: String? = null,
    vm: JornadaViewModel = hiltViewModel(),
) {
    LaunchedEffect(routeUid, routeDate) { vm.init(routeUid, routeDate) }

    val ui by vm.ui.collectAsStateWithLifecycle()
    val session = ui.session
    val state   = session?.state ?: "idle"

    Surface(
        modifier      = modifier.fillMaxWidth(),
        color         = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 2.dp,
    ) {
        Row(
            modifier            = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment   = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Timer
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = if (state == "idle") "Jornada" else vm.formatElapsed(ui.elapsedMs),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily  = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                    ),
                    color = when (state) {
                        "running" -> MaterialTheme.colorScheme.primary
                        "paused"  -> MaterialTheme.colorScheme.tertiary
                        StopStatus.DONE    -> MaterialTheme.colorScheme.secondary
                        else      -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
                if (state != "idle") {
                    Text(
                        text  = "%.1f km".format(ui.distanceKm),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Botones de control
            when (state) {
                "idle", "paused" -> {
                    FilledTonalIconButton(
                        onClick = { if (state == "idle") vm.start() else vm.resume() },
                        colors  = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                        ),
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Iniciar jornada")
                    }
                    if (state == "paused") {
                        FilledTonalIconButton(onClick = vm::finish) {
                            Icon(Icons.Default.FlagCircle, contentDescription = "Finalizar jornada")
                        }
                    }
                }
                "running" -> {
                    FilledTonalIconButton(
                        onClick = vm::pause,
                        colors  = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        ),
                    ) {
                        Icon(Icons.Default.Pause, contentDescription = "Pausar jornada")
                    }
                    FilledTonalIconButton(onClick = vm::finish) {
                        Icon(Icons.Default.FlagCircle, contentDescription = "Finalizar jornada")
                    }
                }
                StopStatus.DONE -> {
                    SuggestionChip(
                        onClick = vm::onReopenRequest,
                        label   = { Text("Finalizada", style = MaterialTheme.typography.labelSmall) },
                        icon    = {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                            )
                        },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            labelColor       = MaterialTheme.colorScheme.secondary,
                            iconContentColor = MaterialTheme.colorScheme.secondary,
                        ),
                    )
                }
            }
        }
    }

    // Diálogo de confirmación para reabrir jornada
    if (ui.showReopenDialog) {
        AlertDialog(
            onDismissRequest = vm::onReopenDismiss,
            icon    = { Icon(Icons.Default.Refresh, null) },
            title   = { Text("¿Reabrir jornada?") },
            text    = { Text("Volverá a estado activo. El tiempo acumulado se conserva.") },
            confirmButton = {
                Button(onClick = vm::confirmReopen) { Text("Reabrir") }
            },
            dismissButton = {
                TextButton(onClick = vm::onReopenDismiss) { Text("Cancelar") }
            },
        )
    }

    // ── Resumen de jornada — al finalizar ─────────────────────
    ui.summary?.let { summary ->
        AlertDialog(
            onDismissRequest = vm::dismissSummary,
            icon  = { Icon(Icons.Default.FlagCircle, null,
                tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Jornada finalizada") },
            text  = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Métricas principales en fila
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        SummaryMetric(
                            value = vm.formatElapsed(summary.elapsedMs),
                            label = "Tiempo",
                            icon  = Icons.Default.Timer,
                        )
                        SummaryMetric(
                            value = "%.1f km".format(summary.distanceKm),
                            label = "Recorrido",
                            icon  = Icons.Default.Route,
                        )
                        SummaryMetric(
                            value = "${summary.stopsDone}/${summary.stopsTotal}",
                            label = "Visitadas",
                            icon  = Icons.Default.CheckCircle,
                        )
                    }
                    HorizontalDivider()
                    // Desglose de paradas
                    SummaryRow("Paradas completadas", summary.stopsDone,
                        MaterialTheme.colorScheme.primary)
                    if (summary.stopsSkipped > 0) {
                        SummaryRow("Paradas omitidas", summary.stopsSkipped,
                            MaterialTheme.colorScheme.tertiary)
                    }
                    if (summary.stopsPending > 0) {
                        SummaryRow("Paradas pendientes", summary.stopsPending,
                            MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                Button(onClick = vm::dismissSummary) { Text("Entendido") }
            },
        )
    }
}

@Composable
private fun SummaryMetric(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(22.dp),
            tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleMedium,
            fontFamily = FontFamily.Monospace)
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SummaryRow(label: String, count: Int, color: androidx.compose.ui.graphics.Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text("$count", style = MaterialTheme.typography.bodyMedium,
            color = color,
            fontFamily = FontFamily.Monospace)
    }
}
